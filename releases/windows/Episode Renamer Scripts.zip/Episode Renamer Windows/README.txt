Episode Renamer for Windows

1. Extract this entire folder from the ZIP before running it.
2. Double-click Open Episode Renamer.vbs.
3. Choose the video folder, enter the show title and season, then Preview.
4. Review the changes and click Rename files.

After the first launch, an Episode Renamer shortcut with the orange icon
is created in this folder. You can use that shortcut for later launches.
Keep all files in the extracted folder together.

If Python 3 with Tkinter is missing, a Yes/No dialog offers to download
and install official Python 3.14.7. Installation requires internet.
If declined, nothing is installed. No terminal window is needed.

Supports bracketed episodes, trailing episodes (Durarara_2-28), S01E05,
and OVA/OAD/Special files (season 00). Episode numbers are preserved.
Each run handles one show/season folder, without scanning subfolders.

This is a script-based Windows launcher, not a standalone EXE.
Requires Windows PowerShell, Windows Script Host and .NET Framework.
Designed for Windows 10/11. Some managed PCs disable script launchers.
The Windows setup and launcher have not been tested on Windows.
